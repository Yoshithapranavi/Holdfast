const API_BASE_URL = "http://localhost:4000";

type ApiErrorResponse = {
  error?: {
    code?: string;
    message?: string;
  };
};

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const errorData = data as ApiErrorResponse | null;

    throw new Error(
      errorData?.error?.message ||
      `Request failed with status ${response.status}`
    );
  }

  return data as T;
}

export type User = {
  id: string;
  name: string;
  email?: string;
  handle: string;
  bio?: string | null;
  city?: string | null;
  avatarColor?: string | null;
};

export type AuthResponse = {
  token: string;
  user: User;
};

export type RegisterInput = {
  name: string;
  email: string;
  password: string;
  handle: string;
};

export type LoginInput = {
  email: string;
  password: string;
};

export async function register(
  input: RegisterInput
): Promise<AuthResponse> {
  return request<AuthResponse>("/auth/register", {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function login(
  input: LoginInput
): Promise<AuthResponse> {
  return request<AuthResponse>("/auth/login", {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function getCurrentUser(token: string): Promise<User> {
  return request<User>("/auth/me", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}
export type GoalMetric =
  | "DISTANCE"
  | "DURATION"
  | "FREQUENCY"
  | "HABIT"
  | "CUSTOM";

export type GoalStatus =
  | "ACTIVE"
  | "FINISHED"
  | "ARCHIVED";

export type GoalVisibility =
  | "PUBLIC"
  | "PARTNERS"
  | "PRIVATE";

export type GoalMilestone = {
  id: string;
  title: string;
  targetValue?: number | null;
  achievedAt?: string | null;
};

export type Goal = {
  id: string;
  title: string;
  metric: GoalMetric;
  currentValue: number;
  targetValue: number;
  unit: string;
  deadline?: string | null;
  visibility: GoalVisibility;
  status: GoalStatus;
  createdAt: string;
  updatedAt: string;
  milestones?: GoalMilestone[];
};

export type CreateGoalInput = {
  title: string;
  metric: GoalMetric;
  targetValue: number;
  unit: string;
  deadline?: string;
  visibility?: GoalVisibility;
};

export async function getMyGoals(
  token: string,
  status?: GoalStatus
): Promise<Goal[]> {
  const query = status
    ? `?status=${encodeURIComponent(status)}`
    : "";

  return request<Goal[]>(`/goals/mine${query}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

export async function createGoal(
  token: string,
  input: CreateGoalInput
): Promise<Goal> {
  return request<Goal>("/goals", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(input),
  });
}
export type SessionType =
  | "RUN"
  | "STRENGTH"
  | "SWIM"
  | "CYCLE"
  | "MOBILITY"
  | "OTHER";

export type SessionEffort =
  | "EASY"
  | "STEADY"
  | "HARD";

export type WorkoutSession = {
  id: string;
  userId: string;
  type: SessionType;
  occurredAt: string;
  durationSeconds: number;
  distanceMeters?: number | null;
  effort?: SessionEffort | null;
  notes?: string | null;
  visibility: GoalVisibility;
  goalId?: string | null;
  challengeMemberId?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type CreateSessionInput = {
  type: SessionType;
  occurredAt: string;
  durationSeconds: number;
  distanceMeters?: number;
  effort?: SessionEffort;
  notes?: string;
  visibility?: GoalVisibility;
  goalId?: string;
  challengeMemberId?: string;
  shareToFeed?: boolean;
};

export async function getMySessions(
  token: string,
  limit = 20
): Promise<WorkoutSession[]> {
  return request<WorkoutSession[]>(
    `/sessions/mine?limit=${limit}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
}

export async function createSession(
  token: string,
  input: CreateSessionInput
): Promise<WorkoutSession> {
  return request<WorkoutSession>("/sessions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(input),
  });
}