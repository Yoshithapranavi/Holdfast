import { getCurrentUser, type User } from "./api";

const TOKEN_KEY = "holdfast_token";

export function saveToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export async function getAuthenticatedUser(): Promise<User | null> {
  const token = getToken();

  if (!token) {
    return null;
  }

  try {
    return await getCurrentUser(token);
  } catch {
    clearToken();
    return null;
  }
}