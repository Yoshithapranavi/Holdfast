"use client";

import { FormEvent, useState } from "react";
import { login, register } from "../../lib/api";
import { saveToken } from "../../lib/auth";

export default function AuthPage() {
    const [mode, setMode] = useState<"login" | "register">("login");

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [handle, setHandle] = useState("");
    const [password, setPassword] = useState("");

    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);

    async function handleSubmit(event: FormEvent) {
        event.preventDefault();

        setLoading(true);
        setMessage("");

        try {
            const response =
                mode === "login"
                    ? await login({
                        email,
                        password,
                    })
                    : await register({
                        name,
                        email,
                        password,
                        handle,
                    });

            saveToken(response.token);

            setMessage(`Welcome, ${response.user.name}!`);
        } catch (error) {
            setMessage(
                error instanceof Error
                    ? error.message
                    : "Something went wrong"
            );
        } finally {
            setLoading(false);
        }
    }

    return (
        <main style={{ padding: 40, maxWidth: 500, margin: "0 auto" }}>
            <h1>
                {mode === "login" ? "Login" : "Create Account"}
            </h1>

            <form onSubmit={handleSubmit}>
                {mode === "register" && (
                    <>
                        <input
                            placeholder="Name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                        />

                        <input
                            placeholder="Handle"
                            value={handle}
                            onChange={(e) => setHandle(e.target.value)}
                        />
                    </>
                )}

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />

                <button type="submit" disabled={loading}>
                    {loading
                        ? "Please wait..."
                        : mode === "login"
                            ? "Login"
                            : "Register"}
                </button>
            </form>

            {message && <p>{message}</p>}

            <button
                type="button"
                onClick={() => {
                    setMode(mode === "login" ? "register" : "login");
                    setMessage("");
                }}
            >
                Switch to {mode === "login" ? "Register" : "Login"}
            </button>
        </main>
    );
}