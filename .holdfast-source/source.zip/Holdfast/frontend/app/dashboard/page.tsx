"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { useAuth } from "../providers";
import {
    getMyGoals,
    getMySessions,
    type Goal,
    type WorkoutSession,
} from "../../lib/api";
import LogWorkoutForm from "../components/LogWorkoutForm";

function formatDate(date: Date) {
    return new Intl.DateTimeFormat("en-GB", {
        weekday: "long",
        day: "numeric",
        month: "long",
    }).format(date);
}

function formatShortDate(value: string) {
    return new Intl.DateTimeFormat("en-GB", {
        weekday: "short",
        day: "numeric",
        month: "short",
    }).format(new Date(value));
}

function formatSessionDate(value: string) {
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
    }).format(new Date(value));
}

function formatDuration(seconds: number) {
    const minutes = Math.round(seconds / 60);

    if (minutes < 60) {
        return `${minutes}:00`;
    }

    const hours = Math.floor(minutes / 60);
    const remaining = minutes % 60;

    return `${hours}:${String(remaining).padStart(2, "0")}`;
}

function formatGoalValue(value: number) {
    if (Number.isInteger(value)) {
        return String(value);
    }

    return value.toFixed(1);
}

function getInitials(name: string) {
    return (
        name
            .trim()
            .split(/\s+/)
            .map((part) => part[0])
            .join("")
            .slice(0, 2)
            .toUpperCase() || "HF"
    );
}

function getWeekStart(date: Date) {
    const result = new Date(date);
    const day = result.getDay();
    const mondayOffset = day === 0 ? -6 : 1 - day;

    result.setHours(0, 0, 0, 0);
    result.setDate(result.getDate() + mondayOffset);

    return result;
}

function sameDay(first: Date, second: Date) {
    return (
        first.getFullYear() === second.getFullYear() &&
        first.getMonth() === second.getMonth() &&
        first.getDate() === second.getDate()
    );
}

function getWeekDays(sessions: WorkoutSession[]) {
    const today = new Date();
    const monday = getWeekStart(today);

    const labels = ["M", "T", "W", "T", "F", "S", "S"];

    return labels.map((label, index) => {
        const date = new Date(monday);
        date.setDate(monday.getDate() + index);

        const hasSession = sessions.some((session) =>
            sameDay(new Date(session.occurredAt), date),
        );

        const isToday = sameDay(today, date);
        const isPast = date < today && !isToday;

        return {
            label,
            date,
            hasSession,
            isToday,
            isPast,
        };
    });
}

function getWeeklySessionCounts(sessions: WorkoutSession[]) {
    const currentMonday = getWeekStart(new Date());

    return Array.from({ length: 8 }, (_, index) => {
        const weekStart = new Date(currentMonday);
        weekStart.setDate(currentMonday.getDate() - (7 - index) * 7);

        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 7);

        return sessions.filter((session) => {
            const date = new Date(session.occurredAt);
            return date >= weekStart && date < weekEnd;
        }).length;
    });
}

function getSessionTitle(session: WorkoutSession) {
    const type = session.type.toLowerCase();

    if (type === "run") {
        return "Run";
    }

    if (type === "cycle") {
        return "Cycling";
    }

    if (type === "swim") {
        return "Swim";
    }

    if (type === "strength") {
        return "Strength";
    }

    return session.type;
}

function SessionIcon({ type }: { type: WorkoutSession["type"] }) {
    if (type === "RUN") {
        return (
            <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#12161A"
                strokeWidth="2"
                aria-hidden="true"
            >
                <circle cx="13" cy="4" r="2" />
                <path d="M7 20l3-5 4 2 2-6" />
                <path d="m16 11 4-1" />
            </svg>
        );
    }

    if (type === "CYCLE") {
        return (
            <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#12161A"
                strokeWidth="1.8"
                aria-hidden="true"
            >
                <circle cx="6" cy="17" r="4" />
                <circle cx="18" cy="17" r="4" />
                <path d="M6 17l4-8h4l4 8M10 9l-2-3M14 9l3-3" />
            </svg>
        );
    }

    if (type === "SWIM") {
        return (
            <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#12161A"
                strokeWidth="1.8"
                aria-hidden="true"
            >
                <path d="M3 9c3 0 3-2 6-2s3 2 6 2 3-2 6-2" />
                <path d="M3 15c3 0 3-2 6-2s3 2 6 2 3-2 6-2" />
                <path d="M3 20c3 0 3-2 6-2s3 2 6 2 3-2 6-2" />
            </svg>
        );
    }

    return (
        <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#12161A"
            strokeWidth="1.8"
            aria-hidden="true"
        >
            <path d="M6 5v14M18 5v14M6 8h12M6 16h12" />
        </svg>
    );
}

export default function DashboardPage() {
    const router = useRouter();
    const { user, loading } = useAuth();

    const [goals, setGoals] = useState<Goal[]>([]);
    const [sessions, setSessions] = useState<WorkoutSession[]>([]);
    const [loadingData, setLoadingData] = useState(true);
    const [showLogForm, setShowLogForm] = useState(false);
    const [message, setMessage] = useState("");

    async function loadDashboard() {
        if (!user) {
            return;
        }

        const token = localStorage.getItem("holdfast_token");

        if (!token) {
            return;
        }

        setLoadingData(true);

        try {
            const [goalData, sessionData] = await Promise.all([
                getMyGoals(token, "ACTIVE"),
                getMySessions(token, 100),
            ]);

            setGoals(goalData);
            setSessions(sessionData);
            setMessage("");
        } catch (error) {
            console.error("Failed to load dashboard:", error);
            setMessage("Unable to load dashboard data.");
        } finally {
            setLoadingData(false);
        }
    }

    useEffect(() => {
        if (!loading && !user) {
            router.replace("/auth");
        }
    }, [loading, user, router]);

    useEffect(() => {
        if (user) {
            loadDashboard();
        }
    }, [user]);

    const today = new Date();

    const weekDays = useMemo(
        () => getWeekDays(sessions),
        [sessions],
    );

    const weeklyCounts = useMemo(
        () => getWeeklySessionCounts(sessions),
        [sessions],
    );

    const thisWeekSessions = useMemo(() => {
        const monday = getWeekStart(new Date());

        const nextMonday = new Date(monday);
        nextMonday.setDate(monday.getDate() + 7);

        return sessions.filter((session) => {
            const date = new Date(session.occurredAt);
            return date >= monday && date < nextMonday;
        }).length;
    }, [sessions]);

    const todaySessions = useMemo(
        () =>
            sessions.filter((session) =>
                sameDay(new Date(session.occurredAt), today),
            ),
        [sessions, today],
    );

    const activeGoal = goals[0];

    const remainingGoalValue = activeGoal
        ? Math.max(
            0,
            activeGoal.targetValue - activeGoal.currentValue,
        )
        : 0;

    const activeGoalPercent = activeGoal
        ? activeGoal.targetValue > 0
            ? Math.min(
                100,
                Math.round(
                    (activeGoal.currentValue / activeGoal.targetValue) * 100,
                ),
            )
            : 0
        : 0;

    const completedGoals = goals.filter(
        (goal) =>
            goal.targetValue > 0 &&
            goal.currentValue >= goal.targetValue,
    ).length;

    const maxWeeklyCount = Math.max(
        1,
        ...weeklyCounts,
    );

    if (loading || !user) {
        return (
            <main className="shell sec">
                <div className="plate" style={{ padding: "40px" }}>
                    <p className="muted">Loading Holdfast...</p>
                </div>
            </main>
        );
    }

    return (
        <main className="sec shell" id="dash">
            {/* =========================
          SECTION HEADER
         ========================= */}

            <div className="sec-head">
                <div className="sec-no num">03</div>

                <div>
                    <h2 className="sec-title">
                        Dashboard — the day sheet
                    </h2>

                    <p className="sec-task">
                        Task: <b>do the one thing today asks for.</b>{" "}
                        The top band carries a single next action; everything
                        below is evidence, not decoration. No metric-card row,
                        no rings — consistency is tallied the way a coach would
                        mark a wall chart.
                    </p>
                </div>
            </div>

            <div className="plate">
                {/* =========================
            APP BAR
           ========================= */}

                <div className="appbar">
                    <div className="mark">
                        <svg
                            className="knot"
                            viewBox="0 0 24 24"
                            fill="none"
                            aria-hidden="true"
                        >
                            <path
                                d="M4 6h6a5 5 0 0 1 0 10H8"
                                stroke="#D2142F"
                                strokeWidth="3"
                            />

                            <path
                                d="M20 18h-6a5 5 0 0 1 0-10h2"
                                stroke="#12161A"
                                strokeWidth="3"
                            />
                        </svg>

                        HOLDFAST
                    </div>

                    <nav className="appnav">
                        <button
                            type="button"
                            className="on"
                            onClick={() => router.push("/dashboard")}
                        >
                            Today
                        </button>

                        <button
                            type="button"
                            onClick={() => router.push("/dashboard")}
                        >
                            Goals
                        </button>

                        <button type="button" disabled>
                            Challenges
                        </button>

                        <button type="button" disabled>
                            Progress
                        </button>

                        <button type="button" disabled>
                            Feed
                        </button>
                    </nav>

                    <div className="appbar-r">
                        <div className="srch">
                            <svg
                                width="14"
                                height="14"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                aria-hidden="true"
                            >
                                <circle cx="11" cy="11" r="7" />
                                <path d="m20 20-3.5-3.5" />
                            </svg>

                            Search people,challenges
                        </div>

                        <button
                            type="button"
                            className="bell"
                            aria-label="Notifications"
                        >
                            <svg
                                width="20"
                                height="20"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="1.9"
                                aria-hidden="true"
                            >
                                <path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" />
                                <path d="M13.7 21a22 22 0 0 1-3.4 0" />
                            </svg>

                            <i />
                        </button>

                        <span className="av av-28 a-nf">
                            {getInitials(user.name)}
                        </span>
                    </div>
                </div>

                {/* =========================
            DAY BAND
           ========================= */}

                <div className="day">
                    <div className="day-l">
                        <p className="day-date">
                            {formatDate(today)}
                        </p>

                        <h3 className="disp day-h">
                            {activeGoal ? (
                                <>
                                    {activeGoal.title}
                                    <br />
                                    {activeGoalPercent}% complete.
                                </>
                            ) : (
                                <>
                                    No active commitment.
                                    <br />
                                    Create your first goal.
                                </>
                            )}
                        </h3>

                        <p className="day-sub">
                            {activeGoal
                                ? `${formatGoalValue(
                                    activeGoal.currentValue,
                                )} of ${formatGoalValue(
                                    activeGoal.targetValue,
                                )} ${activeGoal.unit} completed.`
                                : "Create an active goal to start tracking your commitment."}
                        </p>

                        <div
                            className="row"
                            style={{
                                gap: "10px",
                                flexWrap: "wrap",
                                marginTop: "24px",
                            }}
                        >
                            <button
                                type="button"
                                className="btn btn-pri btn-lg"
                                onClick={() =>
                                    setShowLogForm((value) => !value)
                                }
                            >
                                {showLogForm
                                    ? "Close session form"
                                    : "Log this session"}
                            </button>

                            <button
                                type="button"
                                className="btn btn-lg day-b2"
                                disabled
                            >
                                Move to tomorrow
                            </button>

                            <button
                                type="button"
                                className="btn btn-lg day-b3"
                                disabled
                            >
                                I&apos;m injured
                            </button>
                        </div>
                    </div>

                    <div className="day-r">
                        <div
                            className="row-b"
                            style={{ marginBottom: "14px" }}
                        >
                            <span
                                className="tiny"
                                style={{
                                    color: "#9BA7B3",
                                    fontWeight: 700,
                                }}
                            >
                                This week
                            </span>

                            <span className="tag tag-amber">
                                {activeGoal
                                    ? `${formatGoalValue(
                                        remainingGoalValue,
                                    )} left`
                                    : "No goal"}
                            </span>
                        </div>

                        <div className="wk">
                            {weekDays.map((day) => {
                                let className = "wd";

                                if (day.isToday) {
                                    className += " today";
                                } else if (day.hasSession) {
                                    className += " done";
                                } else if (day.isPast) {
                                    className += " rest";
                                } else {
                                    className += " plan";
                                }

                                return (
                                    <span
                                        key={day.date.toISOString()}
                                        className={className}
                                        title={day.date.toDateString()}
                                    >
                                        {day.label}
                                    </span>
                                );
                            })}
                        </div>

                        <div className="day-streak">
                            <b className="num">
                                {thisWeekSessions}
                            </b>

                            <div>
                                <span>sessions this week</span>

                                <span
                                    className="tiny"
                                    style={{ color: "#7C8894" }}
                                >
                                    {todaySessions.length > 0
                                        ? "Session logged today"
                                        : "No session logged today"}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* =========================
            LOG SESSION
           ========================= */}

                {showLogForm && (
                    <div
                        style={{
                            padding: "30px",
                            borderBottom: "1px solid var(--mist)",
                            background: "var(--card)",
                        }}
                    >
                        <div className="row-b">
                            <div>
                                <h4 className="h-sec">
                                    Log this session
                                </h4>

                                <p
                                    className="tiny muted"
                                    style={{ margin: "4px 0 0" }}
                                >
                                    Record your workout and optionally connect
                                    it to an active goal.
                                </p>
                            </div>

                            <button
                                type="button"
                                className="btn btn-sm btn-ghost"
                                onClick={() => setShowLogForm(false)}
                            >
                                Close
                            </button>
                        </div>

                        <div style={{ marginTop: "20px" }}>
                            <LogWorkoutForm
                                goals={goals}
                                onCreated={async () => {
                                    setMessage(
                                        "Session logged successfully.",
                                    );

                                    setShowLogForm(false);

                                    await loadDashboard();
                                }}
                            />
                        </div>
                    </div>
                )}

                {/* =========================
            EVIDENCE BODY
           ========================= */}

                <div className="dash-body">
                    <div className="dash-main">
                        {/* OPEN COMMITMENTS */}

                        <div
                            className="row-b"
                            style={{ marginBottom: "6px" }}
                        >
                            <h4 className="h-sec">
                                Open commitments
                            </h4>

                            <button
                                type="button"
                                className="btn btn-sm btn-ghost"
                                onClick={() => router.push("/dashboard")}
                            >
                                Manage goals
                            </button>
                        </div>

                        {loadingData ? (
                            <div className="ledger">
                                <div className="lrow">
                                    <div>
                                        <p>Loading commitments...</p>
                                    </div>
                                </div>
                            </div>
                        ) : goals.length === 0 ? (
                            <div className="ledger">
                                <div className="lrow">
                                    <div>
                                        <h4>No active commitments</h4>

                                        <p>
                                            Your active goals will appear here.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="ledger">
                                {goals.map((goal) => {
                                    const percent =
                                        goal.targetValue > 0
                                            ? Math.min(
                                                100,
                                                Math.round(
                                                    (goal.currentValue /
                                                        goal.targetValue) *
                                                    100,
                                                ),
                                            )
                                            : 0;

                                    return (
                                        <div
                                            className="lrow"
                                            key={goal.id}
                                        >
                                            <div>
                                                <h4>{goal.title}</h4>

                                                <p className="num">
                                                    {formatGoalValue(
                                                        goal.currentValue,
                                                    )}{" "}
                                                    /{" "}
                                                    {formatGoalValue(
                                                        goal.targetValue,
                                                    )}{" "}
                                                    {goal.unit}
                                                </p>

                                                <div
                                                    className="bar"
                                                    style={{
                                                        marginTop: "9px",
                                                        maxWidth: "420px",
                                                    }}
                                                >
                                                    <i
                                                        className={
                                                            percent > 0
                                                                ? "crim"
                                                                : ""
                                                        }
                                                        style={{
                                                            width: `${percent}%`,
                                                        }}
                                                    />
                                                </div>
                                            </div>

                                            <div className="lrow-r">
                                                <span className="tag">
                                                    {goal.metric}
                                                </span>

                                                <span
                                                    className={
                                                        percent >= 100
                                                            ? "tag tag-crim"
                                                            : "tag"
                                                    }
                                                >
                                                    {percent}%
                                                </span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}

                        {/* LAST SESSIONS */}

                        <div
                            className="row-b"
                            style={{
                                margin: "30px 0 6px",
                            }}
                        >
                            <h4 className="h-sec">
                                Last sessions
                            </h4>

                            <span className="tiny">
                                {sessions.length} logged
                            </span>
                        </div>

                        {sessions.length === 0 ? (
                            <div className="ledger">
                                <div className="lrow">
                                    <div>
                                        <h4>No sessions yet</h4>

                                        <p>
                                            Log your first workout to start
                                            building your activity record.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="ledger">
                                {sessions.slice(0, 5).map((session) => (
                                    <div
                                        className="srow"
                                        key={session.id}
                                    >
                                        <div className="sicon">
                                            <SessionIcon type={session.type} />
                                        </div>

                                        <div>
                                            <b>
                                                {getSessionTitle(session)}
                                                {session.distanceMeters != null &&
                                                    ` · ${(
                                                        session.distanceMeters / 1000
                                                    ).toFixed(2)} km`}
                                            </b>

                                            <span className="num">
                                                {formatShortDate(
                                                    session.occurredAt,
                                                )}{" "}
                                                ·{" "}
                                                {formatDuration(
                                                    session.durationSeconds,
                                                )}
                                            </span>
                                        </div>

                                        <div className="srow-note">
                                            {session.notes
                                                ? `“${session.notes}”`
                                                : session.effort
                                                    ? `Effort: ${session.effort}`
                                                    : "Workout session logged."}
                                        </div>

                                        <div>
                                            <span className="tag tag-out">
                                                {session.effort
                                                    ? session.effort
                                                    : "Logged"}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* =========================
              SIDEBAR
             ========================= */}

                    <aside className="dash-side">
                        {/* ACCOUNT */}

                        <div className="side-block">
                            <h4
                                className="h-sec"
                                style={{ marginBottom: "12px" }}
                            >
                                Your account
                            </h4>

                            <div className="todo">
                                <span className="av av-28 a-nf">
                                    {getInitials(user.name)}
                                </span>

                                <div>
                                    <p>
                                        <b>{user.name}</b>
                                    </p>

                                    <p>
                                        @{user.handle}
                                    </p>

                                    <p>{user.email}</p>
                                </div>
                            </div>
                        </div>

                        {/* TODAY */}

                        <div className="side-block">
                            <h4
                                className="h-sec"
                                style={{ marginBottom: "12px" }}
                            >
                                Today
                            </h4>

                            <div className="todo">
                                <span className="tag tag-crim">
                                    {todaySessions.length}
                                </span>

                                <div>
                                    <p>
                                        <b>
                                            {todaySessions.length === 1
                                                ? "Session logged today."
                                                : todaySessions.length > 1
                                                    ? "Sessions logged today."
                                                    : "No session logged today."}
                                        </b>
                                    </p>

                                    <p>
                                        {activeGoal
                                            ? `${formatGoalValue(
                                                activeGoal.currentValue,
                                            )} / ${formatGoalValue(
                                                activeGoal.targetValue,
                                            )} ${activeGoal.unit} on active goal.`
                                            : "Create an active goal to begin tracking."}
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* DASHBOARD STATUS */}

                        <div className="side-block">
                            <h4
                                className="h-sec"
                                style={{ marginBottom: "12px" }}
                            >
                                Dashboard status
                            </h4>

                            <ul className="pact">
                                <li>
                                    <span className="av av-28 a-nf">
                                        {goals.length}
                                    </span>

                                    <p>
                                        <b>Active goals</b>
                                    </p>
                                </li>

                                <li>
                                    <span className="av av-28 a-tm">
                                        {completedGoals}
                                    </span>

                                    <p>
                                        <b>Goals completed</b>
                                    </p>
                                </li>

                                <li>
                                    <span className="av av-28 a-sw">
                                        {sessions.length}
                                    </span>

                                    <p>
                                        <b>Sessions logged</b>
                                    </p>
                                </li>
                            </ul>
                        </div>

                        {/* HOLDFAST */}

                        <div className="side-block up">
                            <span
                                className="tag tag-amber"
                                style={{ marginBottom: "10px" }}
                            >
                                Holdfast
                            </span>

                            <h4
                                className="disp-tight"
                                style={{
                                    fontSize: "20px",
                                    marginBottom: "6px",
                                }}
                            >
                                Keep the record honest.
                            </h4>

                            <p
                                className="tiny muted"
                                style={{ margin: 0 }}
                            >
                                Log consistently. Keep your commitments
                                visible. Build evidence over time.
                            </p>
                        </div>
                    </aside>
                </div>

                {/* =========================
            CONSISTENCY
           ========================= */}

                <div className="cons">
                    <div className="cons-head">
                        <div>
                            <h4 className="h-sec">
                                Sessions per week since June
                            </h4>

                            <p
                                className="tiny muted"
                                style={{ margin: "4px 0 0" }}
                            >
                                Each stroke is one logged session.
                                Recent activity is shown at the end.
                            </p>
                        </div>

                        <div className="cons-nums">
                            <div>
                                <b className="num">
                                    {thisWeekSessions}
                                </b>

                                <span>sessions this week</span>
                            </div>

                            <div>
                                <b className="num">
                                    {sessions.length}
                                </b>

                                <span>sessions</span>
                            </div>

                            <div>
                                <b className="num">
                                    {goals.length}
                                </b>

                                <span>active goals</span>
                            </div>
                        </div>
                    </div>

                    <div className="tally">
                        {weeklyCounts.map((count, index) => {
                            const height =
                                count === 0
                                    ? 0
                                    : Math.max(
                                        8,
                                        Math.min(
                                            44,
                                            (count / maxWeeklyCount) * 44,
                                        ),
                                    );

                            return (
                                <div
                                    className="tw"
                                    key={`week-${index}`}
                                >
                                    <svg
                                        width="18"
                                        height="48"
                                        viewBox="0 0 18 48"
                                        fill="none"
                                        aria-hidden="true"
                                    >
                                        <line
                                            x1="9"
                                            y1={48}
                                            x2="9"
                                            y2={48 - height}
                                            className={
                                                index ===
                                                    weeklyCounts.length - 1
                                                    ? "strokes hot"
                                                    : count === 0
                                                        ? "strokes miss"
                                                        : "strokes"
                                            }
                                            strokeWidth="4"
                                        />
                                    </svg>

                                    <b>
                                        W{index + 1}
                                    </b>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>

            {message && (
                <div
                    className="tag tag-crim"
                    style={{
                        marginTop: "12px",
                        padding: "8px 12px",
                    }}
                >
                    {message}
                </div>
            )}
        </main>
    );
}