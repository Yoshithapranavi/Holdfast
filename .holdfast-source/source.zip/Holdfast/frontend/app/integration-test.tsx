"use client";

import { useState } from "react";

export default function IntegrationTest() {
  const [result, setResult] = useState("Not tested");

  async function testBackend() {
    try {
      const response = await fetch("http://localhost:4000/health");
      const data = await response.json();

      setResult(JSON.stringify(data));
    } catch (error) {
      setResult(
        error instanceof Error ? error.message : "Request failed"
      );
    }
  }

  return (
    <main style={{ padding: 40 }}>
      <h1>Holdfast Integration Test</h1>

      <button onClick={testBackend}>
        Test Backend Connection
      </button>

      <pre>{result}</pre>
    </main>
  );
}