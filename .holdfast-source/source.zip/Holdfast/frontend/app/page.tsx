export default function Home() {
  return (
    <main className="holdfast-frame">
      <iframe
        src="/reference/holdfast.html"
        title="Holdfast Fitness Accountability Network"
      />
    </main>
  );
}