"use client";

import { FormEvent, useState } from "react";
import {
    createSession,
    type SessionEffort,
    type SessionType,
    type Goal,
} from "../../lib/api";
import { getToken } from "../../lib/auth";

type LogWorkoutFormProps = {
    goals: Goal[];
    onCreated: () => Promise<void>;
};

export default function LogWorkoutForm({
    goals,
    onCreated,
}: LogWorkoutFormProps) {
    const [type, setType] = useState<SessionType>("RUN");
    const [durationMinutes, setDurationMinutes] = useState("30");
    const [distanceKm, setDistanceKm] = useState("");
    const [effort, setEffort] = useState<SessionEffort>("STEADY");
    const [notes, setNotes] = useState("");
    const [goalId, setGoalId] = useState("");

    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");

    async function handleSubmit(event: FormEvent) {
        event.preventDefault();

        const token = getToken();

        if (!token) {
            setError("You are not authenticated.");
            return;
        }

        const duration = Number(durationMinutes);

        if (!Number.isFinite(duration) || duration <= 0) {
            setError("Duration must be greater than 0.");
            return;
        }

        const distance = distanceKm
            ? Number(distanceKm)
            : undefined;

        if (
            distance !== undefined &&
            (!Number.isFinite(distance) || distance <= 0)
        ) {
            setError("Distance must be greater than 0.");
            return;
        }

        setSaving(true);
        setMessage("");
        setError("");

        try {
            await createSession(token, {
                type,
                occurredAt: new Date().toISOString(),
                durationSeconds: duration * 60,
                distanceMeters:
                    distance !== undefined ? distance * 1000 : undefined,
                effort,
                notes: notes.trim() || undefined,
                visibility: "PARTNERS",
                goalId: goalId || undefined,
                shareToFeed: false,
            });

            setMessage("Workout logged successfully.");

            setDurationMinutes("30");
            setDistanceKm("");
            setEffort("STEADY");
            setNotes("");
            setGoalId("");

            await onCreated();
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : "Failed to log workout."
            );
        } finally {
            setSaving(false);
        }
    }

    return (
        <section style={{ marginTop: 40 }}>
            <h2>Log Workout</h2>

            <form onSubmit={handleSubmit}>
                <div style={{ marginTop: 15 }}>
                    <label>
                        Workout Type
                        <br />
                        <select
                            value={type}
                            onChange={(e) =>
                                setType(e.target.value as SessionType)
                            }
                        >
                            <option value="RUN">Run</option>
                            <option value="STRENGTH">Strength</option>
                            <option value="SWIM">Swim</option>
                            <option value="CYCLE">Cycle</option>
                            <option value="MOBILITY">Mobility</option>
                            <option value="OTHER">Other</option>
                        </select>
                    </label>
                </div>

                <div style={{ marginTop: 15 }}>
                    <label>
                        Duration (minutes)
                        <br />
                        <input
                            type="number"
                            min="1"
                            value={durationMinutes}
                            onChange={(e) =>
                                setDurationMinutes(e.target.value)
                            }
                        />
                    </label>
                </div>

                <div style={{ marginTop: 15 }}>
                    <label>
                        Distance (km) — optional
                        <br />
                        <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={distanceKm}
                            onChange={(e) =>
                                setDistanceKm(e.target.value)
                            }
                        />
                    </label>
                </div>

                <div style={{ marginTop: 15 }}>
                    <label>
                        Effort
                        <br />
                        <select
                            value={effort}
                            onChange={(e) =>
                                setEffort(e.target.value as SessionEffort)
                            }
                        >
                            <option value="EASY">Easy</option>
                            <option value="STEADY">Steady</option>
                            <option value="HARD">Hard</option>
                        </select>
                    </label>
                </div>

                <div style={{ marginTop: 15 }}>
                    <label>
                        Goal — optional
                        <br />
                        <select
                            value={goalId}
                            onChange={(e) => setGoalId(e.target.value)}
                        >
                            <option value="">No goal</option>

                            {goals.map((goal) => (
                                <option key={goal.id} value={goal.id}>
                                    {goal.title}
                                </option>
                            ))}
                        </select>
                    </label>
                </div>

                <div style={{ marginTop: 15 }}>
                    <label>
                        Notes — optional
                        <br />
                        <textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            maxLength={2000}
                            rows={4}
                        />
                    </label>
                </div>

                <button
                    type="submit"
                    disabled={saving}
                    style={{ marginTop: 20 }}
                >
                    {saving ? "Logging..." : "Log Workout"}
                </button>
            </form>

            {message && (
                <p style={{ marginTop: 15 }}>{message}</p>
            )}

            {error && (
                <p style={{ marginTop: 15 }}>
                    Error: {error}
                </p>
            )}
        </section>
    );
}